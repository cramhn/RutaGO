# Roadmap RutaGO

## v0.2
Base estable del proyecto.

## v0.3
Importar Excel `.xlsx` y detectar columnas.

## v0.4
Optimización automática de rutas.

## v0.5
Reportes, WhatsApp, llamadas y evidencias.

## v1.0
Versión estable para trabajo de campo.
