# Changelog

## v0.2.0-base
- Se crea estructura inicial profesional de RutaGO.
- Se separa HTML, CSS y JavaScript.
- Se agrega manifiesto PWA.
- Se agrega service worker.
- Se agrega soporte inicial para CSV.
- Se agrega guardado local.
