# RutaGO

Aplicación web progresiva para gestionar rutas de visitas de campo.

## Versión
0.2.0-base

## Funciones iniciales
- Crear rutas.
- Importar CSV.
- Abrir direcciones en Waze.
- Abrir direcciones en Google Maps.
- Marcar visitas como visitadas o no realizadas.
- Guardar progreso localmente.
- Exportar reporte CSV.

## Próximas funciones
- Importar Excel `.xlsx`.
- Optimización automática de rutas.
- División por días.
- Reportes PDF.
- WhatsApp, llamadas y evidencias.
