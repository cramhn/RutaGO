const STORE = "rutago_base_v0_2_state";
let db = null;

const waze = (address) => "https://waze.com/ul?q=" + encodeURIComponent(address) + "&navigate=yes";
const maps = (address) => "https://www.google.com/maps/search/?api=1&query=" + encodeURIComponent(address);
const now = () => new Date().toISOString();
const esc = (s) => String(s || "").replace(/[&<>"']/g, (m) => ({
  "&": "&amp;",
  "<": "&lt;",
  ">": "&gt;",
  '"': "&quot;",
  "'": "&#039;"
}[m]));

function save() {
  localStorage.setItem(STORE, JSON.stringify(db));
}

function route() {
  return db.routes[0];
}

function allStops() {
  const result = [];
  route().days.forEach((day) => {
    day.stops.forEach((stop) => {
      result.push({ ...stop, dayTitle: day.title });
    });
  });
  return result;
}

function findStop(id) {
  for (const day of route().days) {
    for (const stop of day.stops) {
      if (stop.id === id) return stop;
    }
  }
  return null;
}

function nextStop() {
  return allStops().find((stop) => (stop.status || "pending") === "pending");
}

function setStatus(id, status) {
  const stop = findStop(id);
  if (!stop) return;
  stop.status = status;
  stop.updatedAt = status === "pending" ? "" : now();
  save();
  render();
}

function saveNote(id, value) {
  const stop = findStop(id);
  if (!stop) return;
  stop.note = value;
  stop.updatedAt = now();
  save();
}

function markNext(status) {
  const next = nextStop();
  if (next) setStatus(next.id, status);
}

function setTab(tab) {
  document.getElementById("pendingTab").classList.toggle("hidden", tab !== "pending");
  document.getElementById("doneTab").classList.toggle("hidden", tab !== "done");
  document.getElementById("toolsTab").classList.toggle("hidden", tab !== "tools");
}

function saveHome() {
  db.home = document.getElementById("homeInput").value.trim();
  save();
  render();
}

function resetProgress() {
  if (!confirm("¿Reiniciar estados y notas?")) return;
  route().days.forEach((day) => {
    day.stops.forEach((stop) => {
      stop.status = "pending";
      stop.note = "";
      stop.updatedAt = "";
    });
  });
  save();
  render();
}

function card(stop) {
  const status = stop.status || "pending";
  const label = status === "done" ? "✅ Visitado" : status === "failed" ? "❌ No realizada" : "☐ Pendiente";
  const cls = status === "done" ? " done" : status === "failed" ? " failed" : "";

  return `
    <div class="card${cls}">
      <span class="badge">${esc(stop.dayTitle)} · ${esc(label)}</span>
      <h3>${stop.order}. ${esc(stop.name)}</h3>
      <div class="addr">📍 ${esc(stop.address)}</div>
      <a class="btn blue" href="${waze(stop.address)}">🚙 Abrir en Waze</a>
      <a class="btn light" href="${maps(stop.address)}">🗺️ Google Maps</a>
      <div class="grid">
        <button class="btn green" onclick="setStatus('${stop.id}','done')">✅ Visitado</button>
        <button class="btn red" onclick="setStatus('${stop.id}','failed')">No realizada</button>
        <button class="btn gray full" onclick="setStatus('${stop.id}','pending')">↩ Devolver a pendientes</button>
      </div>
      <textarea placeholder="Notas de la visita..." oninput="saveNote('${stop.id}', this.value)">${esc(stop.note || "")}</textarea>
    </div>
  `;
}

function render() {
  if (!db) return;

  const stops = allStops();
  const done = stops.filter((s) => s.status === "done").length;
  const failed = stops.filter((s) => s.status === "failed").length;
  const pending = stops.length - done - failed;

  document.getElementById("routeName").textContent = route().name;
  document.getElementById("pendingStat").textContent = pending;
  document.getElementById("doneStat").textContent = done;
  document.getElementById("failedStat").textContent = failed;
  document.getElementById("bar").style.width = stops.length ? Math.round((done / stops.length) * 100) + "%" : "0%";

  const next = nextStop();
  const homeUrl = db.home ? waze(db.home) : "#";

  document.getElementById("footerHome").href = homeUrl;
  document.getElementById("homeWaze2").href = homeUrl;
  document.getElementById("homeInput").value = db.home || "";

  document.getElementById("nextTitle").textContent = next ? `${next.order}. ${next.name}` : "Ruta terminada";
  document.getElementById("nextAddress").textContent = next ? "📍 " + next.address : "No quedan pendientes.";
  document.getElementById("nextWaze").href = next ? waze(next.address) : homeUrl;
  document.getElementById("footerNext").href = next ? waze(next.address) : homeUrl;

  const query = (document.getElementById("search").value || "").toLowerCase().trim();

  const pendingItems = stops
    .filter((s) => (s.status || "pending") === "pending")
    .filter((s) => !query || (s.name + " " + s.address).toLowerCase().includes(query));

  document.getElementById("pendingList").innerHTML = pendingItems.map(card).join("") || '<div class="card"><h3>Sin pendientes</h3></div>';
  document.getElementById("doneList").innerHTML = stops.filter((s) => (s.status || "pending") !== "pending").map(card).join("") || '<div class="card"><h3>Aún no hay visitadas/no realizadas</h3></div>';
}

function parseCSV(text) {
  const rows = [];
  let row = [];
  let current = "";
  let quoted = false;

  for (let i = 0; i < text.length; i++) {
    const char = text[i];
    const next = text[i + 1];

    if (char === '"') {
      if (quoted && next === '"') {
        current += '"';
        i++;
      } else {
        quoted = !quoted;
      }
    } else if (char === "," && !quoted) {
      row.push(current);
      current = "";
    } else if ((char === "\n" || char === "\r") && !quoted) {
      if (char === "\r" && next === "\n") i++;
      row.push(current);
      if (row.some((x) => x.trim())) rows.push(row);
      row = [];
      current = "";
    } else {
      current += char;
    }
  }

  row.push(current);
  if (row.some((x) => x.trim())) rows.push(row);
  return rows;
}

function findHeader(headers, keys) {
  for (const key of keys) {
    const index = headers.findIndex((h) => h.includes(key));
    if (index >= 0) return index;
  }
  return -1;
}

function loadCSV(event) {
  const file = event.target.files[0];
  if (!file) return;

  const reader = new FileReader();

  reader.onload = () => {
    const rows = parseCSV(reader.result);
    if (rows.length < 2) {
      alert("CSV vacío");
      return;
    }

    const headers = rows[0].map((x) => x.trim().toLowerCase());
    const nameIndex = findHeader(headers, ["name", "nombre", "cliente", "contact"]);
    const addressIndex = findHeader(headers, ["address", "direccion", "dirección", "addr"]);

    const stops = [];

    for (let i = 1; i < rows.length; i++) {
      const row = rows[i];
      const name = nameIndex >= 0 ? row[nameIndex] : "Cliente " + i;
      const address = addressIndex >= 0 ? row[addressIndex] : row.filter(Boolean).join(", ");

      if (address.trim()) {
        stops.push({
          id: "csv-" + Date.now() + "-" + i,
          order: i,
          name: name || "Cliente",
          address: address.trim(),
          status: "pending",
          note: "",
          updatedAt: ""
        });
      }
    }

    route().name = "Ruta importada";
    route().days = [{ title: "Ruta importada", stops }];
    save();
    setTab("pending");
    render();
  };

  reader.readAsText(file);
}

function exportCSV() {
  const lines = ["Nombre,Direccion,Estado,Notas,Actualizado"];

  allStops().forEach((stop) => {
    lines.push([stop.name, stop.address, stop.status || "pending", stop.note || "", stop.updatedAt || ""]
      .map((value) => `"${String(value).replaceAll('"', '""')}"`)
      .join(","));
  });

  const blob = new Blob([lines.join("\n")], { type: "text/csv" });
  const link = document.createElement("a");
  link.href = URL.createObjectURL(blob);
  link.download = "reporte_rutago.csv";
  link.click();
}

async function init() {
  const saved = localStorage.getItem(STORE);

  if (saved) {
    db = JSON.parse(saved);
  } else {
    db = await fetch("./data/sample-route.json").then((response) => response.json());
    save();
  }

  render();

  if ("serviceWorker" in navigator) {
    navigator.serviceWorker.register("./service-worker.js").catch(() => {});
  }
}

init();
